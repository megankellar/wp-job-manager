<?php $category = get_the_resume_category(); ?>

<?php $referer = $_SERVER['HTTP_REFERER']; ?>
<?php if (strpos($referer, 'elink') !== false) { $searchCandidates = 1; } ?>

<li id="resume-<?php the_ID(); ?>" <?php resume_class(); ?> <?php echo apply_filters( 'jobify_listing_data', '' ); ?>>
	<div class="row">
		<a href="<?php the_resume_permalink(); ?>">

			<div class="col-xs-12 col-md-5 col-lg-3">
				<?php if(!isset($searchCandidates)){ ?>
                    <h3><?php the_title(); ?></h3>
                    
                    <div class="candidate-title">
                    	<?php the_candidate_title( '<strong>', '</strong> ' ); ?>
                    </div>
                    <?php }else{ ?>
                    <h3><?php the_candidate_title(); ?></h3>
                    <?php } ?>
			</div>

			<div class="position col-xs-12 col-md-5 col-lg-5">
				<?php the_resume_field( 'resume_content' ); ?>
			</div>
			
			<div class="location col-xs-12 col-md-4 col-lg-2">
				<strong><span class="ion-ios-location"></span> Location:</strong><br />
				<?php the_resume_field( 'site_regions' ); ?>
			</div>

			<ul class="meta col-lg-2 <?php if ( $category ) : ?>has-category<?php endif; ?>">
				<?php if ( $category ) : ?>
					<li class="resume-category">
						<strong><span class="ion-pricetag"></span> Industry:</strong><br /> <?php echo $category ?>
					</li>
				<?php endif; ?>

			</ul>
		</a>
	</div>
</li>