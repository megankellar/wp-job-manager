<?php
/**
 * Template Name: Custom RSS Template - Candidatefeed
 */

$query_args = array(
	'post_type'              => 'resume',
	'post_status'            => 'publish',
//	'orderby'                => 'modified',
//	'order'                  => 'DESC',
	'posts_per_page' => 20,
	'tax_query'              => array(),
	'meta_query'             => array(),
	'fields'                 => 'all'
);
if ( ! empty( $_GET['location'] ) ) {
	/* if(isset($terms) && !empty($terms)){
		$location_search    = array( 'relation' => 'OR' );
		foreach($terms as $key=>$term){
			$location_search[] = array(
				'key'     => '_site_regions',
				'value'   => $term[0]->term_id,
			);
		}
		$query_args['meta_query'][] = $location_search;
	} */
	$locations = explode(",",$_GET['location'] );
	$query_args['tax_query']    = array(
		'relation' => 'OR',
		array(
			'taxonomy'         => 'resume_region',
			'field'            => 'slug',
			'terms'            => array_values( $locations ),
			'include_children' => true,
			'operator'         => 'IN'
		),
		array(
			'taxonomy'         => 'resume_region',
			'field'            => 'name',
			'terms'            => array_values( $locations ),
			'include_children' => true,
			'operator'         => 'IN'
		)
	);
}
if ( ! empty( $_GET['industry'] ) ) {
	if(is_numeric( $_GET['industry'])){
		$query_args['tax_query'][] = array(
			'taxonomy'         => 'resume_category',
			'field'            => 'term_id',
			'terms'            => $_GET['industry']
		);
	}else{
		$query_args['tax_query']    = array( 'relation' => 'OR',
			array(
				'taxonomy'         => 'resume_category',
				'field'            => 'slug',
				'terms'            => $_GET['industry']
			),
			array(
				'taxonomy'         => 'resume_category',
				'field'            => 'name',
				'terms'            => $_GET['industry']
			)
		);
	}
}
if ( empty( $query_args['meta_query'] ) ) {
	unset( $query_args['meta_query'] );
}

if ( empty( $query_args['tax_query'] ) ) {
	unset( $query_args['tax_query'] );
}
$postCount = 20; // The number of posts to show in the feed
//$args = array_merge( $wp_query->query_vars,$query_args );
//print_r($args);die;
$posts = new WP_Query($query_args);
header('Content-Type: '.feed_content_type('atom').'; charset='.get_option('blog_charset'), true);
echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>';
?>
<rss version="2.0"
        xmlns:content="http://purl.org/rss/1.0/modules/content/"
        xmlns:wfw="http://wellformedweb.org/CommentAPI/"
        xmlns:dc="http://purl.org/dc/elements/1.1/"
        xmlns:atom="http://www.w3.org/2005/Atom"
        xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
        xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
        <?php do_action('rss2_ns'); ?>>
<channel>
        <title><?php bloginfo_rss('name'); ?> - Feed</title>
        <atom:link href="<?php self_link(); ?>" rel="self" type="application/rss+xml" />
        <link><?php bloginfo_rss('url') ?></link>
        <description><?php bloginfo_rss('description') ?></description>
        <lastBuildDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_lastpostmodified('GMT'), false); ?></lastBuildDate>
        <language><?php echo get_option('rss_language'); ?></language>
        <sy:updatePeriod><?php echo apply_filters( 'rss_update_period', 'hourly' ); ?></sy:updatePeriod>
        <sy:updateFrequency><?php echo apply_filters( 'rss_update_frequency', '1' ); ?></sy:updateFrequency>
        <?php do_action('rss2_head'); ?>
        <?php if( $posts->have_posts() ):
    while( $posts->have_posts() ): $posts->the_post();
       //The secondary loop
	   
		?>
                <item>
                        <title><?=addslashes(html_entity_decode(get_the_title($post->ID), ENT_QUOTES, 'UTF-8'))?></title>
                        <link><?php the_permalink_rss(); ?></link>
						<location><?php the_resume_field( 'site_regions' ); ?></location>
						<industry><?php echo get_the_resume_category(); ?></industry>
						<pubDate><?php echo mysql2date('D, d M Y H:i:s +0000', get_post_time('Y-m-d H:i:s', true), false); ?></pubDate>
                        <dc:creator><?php the_author(); ?></dc:creator>
                        <guid isPermaLink="false"><?php the_guid(); ?></guid>
                        <description><![CDATA[<?php the_excerpt_rss() ?>]]></description>
                        <content:encoded><![CDATA[<?php the_excerpt_rss() ?>]]></content:encoded>
                        <?php rss_enclosure(); ?>
                        <?php do_action('rss2_item'); ?>
                </item>
        <?php endwhile;
endif;
wp_reset_postdata(); ?>
</channel>
</rss>