<?php $category = get_the_resume_category(); ?>

<li id="resume-<?php the_ID(); ?>" <?php resume_class(); ?> <?php echo apply_filters( 'jobify_listing_data', '' ); ?>>
	<div class="row">
		<a href="<?php the_resume_permalink(); ?>">

			<div class="col-xs-12 col-md-5 col-lg-3">
				<h3><?php the_title(); ?></h3>
				<p>JSID: <?php the_resume_field('candidate_jsid');?></p>
				<div class="candidate-title">
					<?php the_candidate_title( '<strong>', '</strong> ' ); ?>
				</div>
			</div>

			<div class="position col-xs-12 col-md-5 col-lg-5">
				<?php the_resume_field( 'resume_content' ); ?>
			</div>
			
			<div class="location col-xs-12 col-md-4 col-lg-2">
				<?php the_resume_field( 'site_regions' ); ?><br /><br />
			</div>

			<ul class="meta col-lg-2 <?php if ( $category ) : ?>has-category<?php endif; ?>">
				<?php if ( $category ) : ?>
					<li class="resume-category">
						<p>Industry: <?php echo $category ?></p>
					</li>
				<?php endif; ?>

				<li class="date"><?php printf( __( 'Updated %s ago', 'jobify' ), human_time_diff( get_the_modified_time( 'U' ), current_time( 'timestamp' ) ) ); ?></li>
			</ul>
		</a>
	</div>
</li>