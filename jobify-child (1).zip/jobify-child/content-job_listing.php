<li id="job_listing-<?php the_ID(); ?>" <?php job_listing_class(); ?> <?php echo apply_filters( 'jobify_listing_data', '' ); ?>>
	<div class="row">
		<a href="<?php the_job_permalink(); ?>" class="job_listing-link">
			
			<div class="position col-xs-12 col-sm-10 col-md-6 col-lg-5">
				<h2><?php the_title(); ?></h2>

				<div class="company">
					<?php echo get_the_job_regions(get_the_ID()); ?>
				</div>
			</div>

			<div class="position col-xs-12 col-sm-10 col-md-6 col-lg-5">	
				<?php the_excerpt(); ?>
			</div>

			<ul class="meta col-lg-2">
				<?php do_action( 'job_listing_meta_start' ); ?>

				<li class="job-type <?php echo get_the_job_type() ? sanitize_title( get_the_job_type()->slug ) : ''; ?>">
				<?php the_custom_field( 'business_advisor' ); ?></li>
				<li class="date"><date><?php printf( __( 'Posted %s ago', 'jobify' ), human_time_diff( get_post_time( 'U' ), current_time( 'timestamp' ) ) ); ?></date></li>

				<?php do_action( 'job_listing_meta_end' ); ?>
			</ul>
		</a>
	</div>
</li>