<?php
/**
 *
 */

global $post;

$skills     = wp_get_object_terms( $post->ID, 'resume_skill', array( 'fields' => 'names' ) );
$education  = get_post_meta( $post->ID, '_candidate_education', true );
$experience = get_post_meta( $post->ID, '_candidate_experience', true );

$info            = get_theme_mod( 'resume-display-sidebar', 'top' );

$has_local_info  = is_array( $skills ) || $education || $experience;

$col_description = 'top' == $info ? '12' : ( $has_local_info ? '6' : '10' );
$col_info        = 'top' == $info ? '12' : ( 'side' == $info ? '4' : '6' );

$curUserRole = km_get_user_role();

?>

<script language="javascript">
    document.title = "Enterprise and Training Company (ETC)&nbsp;Not-for-profit Recruitment Agency";
</script>

<div class="page-header">
   
	<h2 class="page-title"><?php the_title(); ?></h2>
    <h3 class="page-subtitle">
        <ul>
            <?php //do_action( 'single_resume_meta_start' ); ?>
            <li class="job-location location"><?php the_resume_field( 'resume_region' ); ?></li>
            

            <?php do_action( 'single_resume_meta_end' ); ?>
        </ul>
    </h3>
</div>

<div id="content" class="container content-area" role="main">

	<?php if ( resume_manager_user_can_view_resume( $post->ID ) ) : ?>

		<?php do_action( 'single_resume_start' ); ?>

		<?php //locate_template( array( 'sidebar-single-resume-top.php' ), true, false ); ?>

		<div class="resume-overview-content row">

            <div class="resume-description col-md-<?php echo $col_description; ?> col-sm-12" style="margin-top:10px">
                <h2 class="widget-title widget-title--resume-top"><?php _e( 'Description', 'jobify' ); ?></h2>

                <?php echo apply_filters( 'the_resume_description', get_the_content() ); ?>
            <br />
          </div>

            <?php locate_template( array( 'sidebar-single-resume.php' ), true, false ); ?>

            <?php do_action( 'single_resume_end' ); ?>

            <?php 
           
            echo '<script>';
            echo 'jQuery(document).ready(function(){jQuery(".resume-overview-content >p").css("display","none")}); ';
            echo 'var myNode = document.getElementById("jmfe-wrap-work_capacity-multi-label");';
            echo 'myNode.innerHTML = "";';
            
            echo 'var myNode = document.getElementById("jmfe-wrap-jrl_url");';
            echo 'myNode.innerHTML = "";';
            
            echo '</script>';
           ?>


		</div>

		<h3 class="gform_title"><b>If you are interested in this candidate, please call us on <a href="tel:1800 007 400">1800 007 400</a> or complete the form below.</b></h3>
		<?php echo do_shortcode('[gravityform id="7" title="true" description="false"]'); ?>
		
	<?php else : ?>

		<?php get_job_manager_template_part( 'access-denied', 'single-resume', 'resume_manager', RESUME_MANAGER_PLUGIN_DIR . '/templates/' ); ?>

	<?php endif; ?>

</div>


