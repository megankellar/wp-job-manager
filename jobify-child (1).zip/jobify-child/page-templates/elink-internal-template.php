<?php /* Template Name: Elink Internal Pages  */ ?>
<head>
  <title>eLink - Employer app by ETC</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="/wp-content/themes/jobify-child/css/app-styles.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
  rel="stylesheet">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script src="https://use.fontawesome.com/8d3c20d01c.js"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link rel="apple-touch-icon" sizes="128x128" href="http://joblab.etcltd.com.au/wp-content/themes/jobify/images/app/elink-logo.png">
<link rel="icon" href="http://joblab.etcltd.com.au/wp-content/themes/jobify/images/app/elink-logo.png" sizes="32x32">
<?php wp_head(); ?>

</head>

<body>
  <div id="app-container" style="">
    

    <!-- Start Header -->
    <div id="app-header">

       <nav class="navbar navbar-inverse bg-inverse fixed-top">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="http://joblab.etcltd.com.au/elink/"><img src="http://joblab.etcltd.com.au/wp-content/uploads/2018/02/etc-logo-white.png"></a>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="http://joblab.etcltd.com.au/elink/">Home<span class="sr-only">(current)</span></a>
          </li>
             <li class="nav-item">
            <a class="nav-link" href="/elink/candidates" >Search Candidates</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/elink/post-a-vacancy/">Post A Vacancy</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/elink/upload-documents" >Upload Documents</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://etcltd.com.au/employers/wage-subsidies/" target="_blank">Wage Subsidies</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://etcltd.com.au/employers/do-your-staff-require-training/" target="_blank">Staff Training</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="https://etcltd.com.au/employers/youth-jobs-path/" target="_blank">Trial a Young Person</a>
          </li>
        </ul>
       
      </div>
    </nav>
     
  </div>
   <!-- End Header --> 

    <!-- Start Main Content  -->

    <div id="main-content">

  <?php while ( have_posts() ) : the_post(); ?>

  
    <?php if ( Jobify_Page_Header::show_page_header() ) : ?>
    <header class="page-header">
      <h2 class="page-title"><?php the_title(); ?></h2>
    </header>
    <?php endif; ?> 
    

   

    <div id="primary" class="content-area container" role="main" style="margin-top: 1em !important">
      <?php if ( jobify()->get( 'woocommerce' ) ) : ?>
        <?php wc_print_notices(); ?>
      <?php endif; ?>

      <?php get_template_part( 'content', 'page' ); ?>

      <?php do_action( 'jobify_loop_after' ); ?>
    </div><!-- #primary -->

    <?php endwhile; ?>

  <div class="fixed-bottom navbar bg-inverse" style="min-height: 30px"></div>

    </div><!-- Close app-container  -->
  <?php wp_footer(); ?>
</body>
