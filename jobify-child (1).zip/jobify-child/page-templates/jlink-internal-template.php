<?php /* Template Name: jlink Internal Pages  */ ?>
<head>
  <title>jLink - Job Seeker app by ETC</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="/wp-content/themes/jobify-child/css/app-styles.css">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script src="https://use.fontawesome.com/8d3c20d01c.js"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link rel="apple-touch-icon" sizes="128x128" href="../wp-content/uploads/2019/01/jlink-logo-app.png">
<link rel="icon" href="../wp-content/uploads/2019/01/jlink-logo-app.png" sizes="32x32">
<?php wp_head(); ?>

</head>

<body>
  <div id="app-container" style="">
    

    <!-- Start Header -->
    <div id="app-header">

       <nav class=" navbar navbar-inverse jlink-header-background fixed-top">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="http://joblab.etcltd.com.au/jlink/"><img src="../wp-content/uploads/2019/01/etc-logo-white.png"></a>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="https://etcltd.com.au/joblab/elink">Home<span class="sr-only">(current)</span></a>
          </li>
             <li class="nav-item">
            <a class="nav-link" href="https://my.gov.au/LoginServices/main/login?execution=e1s1">My Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/jlink/etc-jobs/">Job Search</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/jlink/document-upload/">Upload Documents</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://directory.wayahead.org.au/" target="_blank">Community Services</a>
          </li>
        </ul>
       
       
      </div>
    </nav>
     
  </div>
   <!-- End Header -->  

    <!-- Start Main Content  -->

    <div id="main-content">

  <?php while ( have_posts() ) : the_post(); ?>

    <!--
    <?php if ( Jobify_Page_Header::show_page_header() ) : ?>
    <header class="page-header">
      <h2 class="page-title"><?php the_title(); ?></h2>
    </header>
    <?php endif; ?> 
    -->
	<!--
    <header class="page-header" style="padding:0px; background-color: #efefef">
      <h2 class="page-title" style="color:#003480"><?php the_title(); ?></h2>
    </header>
	-->
    <div id="primary" class="content-area container" role="main" style="margin-top: 1em !important">
      <?php if ( jobify()->get( 'woocommerce' ) ) : ?>
        <?php wc_print_notices(); ?>
      <?php endif; ?>

      <?php get_template_part( 'content', 'page' ); ?>

      <?php do_action( 'jobify_loop_after' ); ?>
    </div><!-- #primary -->

    <?php endwhile; ?>

  <div class="fixed-bottom navbar bg-inverse" style="min-height: 30px"></div>

    </div><!-- Close app-container  -->
  <?php wp_footer(); ?>
</body>
